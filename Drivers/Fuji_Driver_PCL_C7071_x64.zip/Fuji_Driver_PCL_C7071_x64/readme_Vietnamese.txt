================================================================================
Thỏa thuận cấp phép
================================================================================

Thỏa thuận cấp phép cho phần mềm này (sau đây được gọi là PHẦN MỀM), được định
rõ như sau.

1. Các quyền sở hữu trí tuệ đối với PHẦN MỀM luôn thuộc về Công ty TNHH 
   FUJIFILM Business Innovation (sau đây được nhắc đến là 
   FUJIFILM Business Innovation) cũng như các tác giả bản quyền gốc.

2. PHẦN MỀM chỉ có thể được sử dụng chung với các sản phẩm tương thích của
   FUJIFILM Business Innovation (sau đây được gọi là CÁC SẢN PHẨM TƯƠNG THÍCH)
   tại quốc gia mà bạn mua CÁC SẢN PHẨM TƯƠNG THÍCH đó.

3. Bạn phải tuân theo các lưu ý và giới hạn (sau đây được gọi là LƯU Ý VÀ GIỚI HẠN)
   được FUJIFILM Business Innovation công bố trong khi sử dụng PHẦN MỀM.

4. Bạn không được phép sửa đổi, chỉnh sửa, thực hiện kỹ thuật đảo ngược,
   dịch ngược hay tách rời toàn bộ hay bất kỳ phần nào của
   PHẦN MỀM cho mục đích phân tích PHẦN MỀM.

5. Bạn không được phép phân phối PHẦN MỀM trên mạng lưới thông tin liên lạc hay
   chuyển nhượng, bán, cho thuê hoặc cấp phép PHẦN MỀM đến bất kỳ bên thứ ba nào
   bằng cách chép lại PHẦN MỀM trên bất kỳ phương tiện ghi nào như đĩa mềm hay
   băng từ (băng ghi âm).

6. FUJIFILM Business Innovation, các đối tác kênh của FUJIFILM Business Innovation,
   các đại lý được ủy quyền và các tác giả bản quyền gốc của
   PHẦN MỀM sẽ không chịu trách nhiệm cho bất kỳ tổn
   thất hoặc thiệt hại nào phát sinh từ việc kết hợp với phần cứng hay chương
   trình không được liệt kê trong phần LƯU Ý VÀ GIỚI HẠN của PHẦN MỀM, hoặc từ
   bất kỳ sự chỉnh sửa nào của PHẦN MỀM.

7. FUJIFILM Business Innovation, các đối tác kênh của FUJIFILM Business Innovation,
   các đại lý được ủy quyền và các tác giả bản quyền gốc của
   PHẦN MỀM sẽ không chịu trách nhiệm cho bất kỳ bảo
   hành hoặc khoản đền bù nào liên quan đến PHẦN MỀM.

================================================================================
PCL 6 Print Driver Ver.7.1.10
================================================================================

Tài liệu này cung cấp thông tin bổ sung về trình điều khiển ở
các mục sau:

1. Các sản phẩm phần cứng đích
2. Yêu cầu
3. Chú thích chung
4. LƯU Ý VÀ GIỚI HẠN
  4.1  LƯU Ý VÀ HẠN CHẾ theo trình điều khiển cụ thể
  4.2  LƯU Ý VÀ HẠN CHẾ theo trình điều khiển cụ thể cho Màu
  4.3  LƯU Ý VÀ HẠN CHẾ theo ứng dụng cụ thể
  4.4  LƯU Ý VÀ HẠN CHẾ theo ứng dụng cụ thể cho Màu
5. Cập nhật phần mềm

---------------------------------------------------
1. Các sản phẩm phần cứng đích
---------------------------------------------------
FUJIFILM Apeos 3560 / 3060 / 2560
         Apeos 3561 / 3061 / 2561
         Apeos 5330 / 4830
         Apeos 5570 / 4570
         Apeos 6340
         Apeos 7580 / 6580
         Apeos C3060 / C2560 / C2060
         Apeos C3061 / C2561 / C2061
         Apeos C3567 / C3067 / C2567
         Apeos C4030 / C3530
         Apeos C5240
         Apeos C7070 / C6570 / C5570 / C4570 / C3570 / C3070 / C2570
         Apeos C7071 / C6571 / C5571 / C4571 / C3571 / C3071
         Apeos C8180 / C7580 / C6580
         ApeosPrint 4560 S / 3960 S / 3360 S
         ApeosPrint 5330
         ApeosPrint 6340
         ApeosPrint C4030
         ApeosPrint C5240
         ApeosPrint C5570
         ApeosPro C810 / C750 / C650

---------------------------------------------------
2. Yêu cầu
---------------------------------------------------
Vui lòng lưu ý rằng trình điều khiển in này
hoạt động trên máy tính chạy hệ điều hành sau đây.

  Microsoft(R) Windows(R) 10 x64 Editions
  Microsoft(R) Windows Server(R) 2016
  Microsoft(R) Windows Server(R) 2019
  Microsoft(R) Windows(R) 11
  Microsoft(R) Windows Server(R) 2022
  Microsoft(R) Windows Server(R) 2025

  Vui lòng truy cập trang web của chúng tôi để xem các hệ điều hành được hỗ trợ
  và phần mềm mới nhất.

 
---------------------------------------------------
3. Chú thích chung
---------------------------------------------------
* Đóng tất cả các ứng dụng đang hoạt động trước khi cài đặt
  trình điều khiển in.

* Luôn khởi động lại máy tinh sau khi cài đặt một phiên bản nâng cấp
  của trình điều khiển in.

* Nếu bạn đã xóa một phiên bản cũ hơn của trình điều khiển in,
  hãy luôn khởi động lại máy tính trước khi cài đặt phiên bản mới.

* Một số ứng dụng cung cấp các tùy chọn in liên quan đến
  số lượng bản sao và bản sao được chia bộ.  Luôn chọn
  các tùy chọn in trong ứng dụng trừ khi có các hướng dẫn
  cụ thể khác. Sử dụng các hộp thoại trình điều khiển in để chọn
  các tùy chọn nâng cao như: In 2 mặt, Bộ mẫu hoặc các
  tùy chọn không sẵn dùng trong ứng dụng.

* Luôn đóng các hộp thoại của trình điều khiển in và/hoặc hộp thoại In
  của ứng dụng trước khi bạn thực hiện những thay đổi cho thiết đặt
  mặc định của trình điều khiển in trên Bảng điều khiển.

* Nếu giấy ra offset của công việc không thực hiện tốt với các
  bản sao được chia bộ, bạn có thể thử bỏ chọn tùy chọn
  "Chia bộ" trong ứng dụng và chọn hộp kiểm "Chia bộ" trong
  trình điều khiển in.

* Nếu người dùng hiện thời không khởi chạy hoặc tạo được
  danh bạ fax, anh ấy/cô ấy có thể chưa được cấp quyền truy cập danh bạ.
  Đối với trường hợp truy cập khi chưa được cấp quyền như thế,
  trình điều khiển sẽ hiển thị một thông báo lỗi cho biết không thể
  định vị Danh bạ fax mặc định hoặc không thể nhận biết Danh bạ fax được chỉ định.
  Mặt khác, nếu người dùng muốn những người dùng khác truy cập
  được vào Danh bạ fax của anh ấy/cô ấy, anh ấy/cô ấy phải chỉ định
  các nhóm hoặc người dùng mà anh ấy/cô ấy muốn cho phép truy cập
  và ít nhất phải cấp quyền "Thay đổi" đối với tệp dữ liệu Danh bạ fax.

* Một công việc fax cần được gửi riêng đến mỗi người nhận được
  chỉ định bằng mã F (F-code), mật khẩu hoặc thuộc tính gửi bảo mật.
  Nếu không, máy in sẽ luôn bỏ qua mã F, mật khẩu và thuộc tính gửi
  bảo mật khi gửi một công việc fax đến nhiều người nhận.  Công việc
  được truyền đi luôn được in trực tiếp tại tất cả các đích đến đã xác định.

* Đối với quá trình cài đặt thông qua mạng,
  nếu bạn nhấp chuột phải vào thư mục [Máy in], hãy đến mục
  [Chạy với vai trò người quản trị] từ menu và chọn [Thêm máy in...],
  biểu tượng máy in có thể sẽ không được tạo.

* Việc đổi tên biểu tượng máy in cần phải tuân theo quy ước đặt tên tệp của HĐH.
  Sử dụng các biểu tượng hoặc ký tự đặc biệt có thể phát sinh lỗi đổi tên hoặc
  hoạt động không mong muốn của trình điều khiển in.

* Trước khi cài đặt trình điều khiển in trong môi trường cụm của Windows, bạn cần
  cài đặt trình điều khiển trên mỗi nút trong cụm.

---------------------------------------------------
4. LƯU Ý VÀ GIỚI HẠN
---------------------------------------------------
4.1  LƯU Ý VÀ HẠN CHẾ theo trình điều khiển cụ thể
-------------------------------------------------------
*Về việc sử dụng máy in dùng chung
  Nếu bạn gặp phải vấn đề như dưới đây khi sử dụng máy in dùng chung, bạn có
  thể sửa để in lại đúng ý bằng cách thay đổi giá trị trong
  [Kết xuất tác vụ in trên máy tính khách].
  - Chú thích hoặc phần in chìm không được in đúng cách, kể cả khi đã chỉ định.
  - Thiết đặt xác thực chưa được thể hiện đúng, hoặc cửa sổ bật lên yêu cầu
    xác thực không hiện ra.

* Độ phân giải mặc định của trình điều khiển này là 600dpi. (Được tự động thể hiện)
  Khi thực hiện công việc qua một trình điều khiển có độ phân giải khác với
  độ phân giải của trình điều khiển này, có thể có các lỗi như sau tùy vào
  thông số kỹ thuật hoặc giới hạn của một ứng dụng.

  - Bố cục in của tài liệu bị thay đổi.
  - Kết quả in của các đường kẻ hoặc mẫu hình bị thay đổi.
  - Các đường kẻ không cần thiết có thể được in trên giấy ra.
  - Các đường kẻ cần thiết không được in trên giấy ra.

  Trong những trường hợp như thế, có thể cải thiện tình trạng bằng cách
  thay đổi thiết đặt của [Độ phân giải] trong tab [Nâng cao].

* Cho dù đã chọn [Bỏ qua trang trống], các trang trống
  có thể vẫn sẽ được in trong các tình huống sau.
  - Trang chỉ chứa các ký tự nhảy dòng.
  - Trang chỉ chứa các khoảng trắng.
  - Trang chỉ chứa các ký tự nhảy dòng và các khoảng trắng.
  - Chỉ thị vẽ nền trắng được gửi từ ứng dụng.

* Lưu ý và hạn chế về môi trường máy chủ-máy khách
- Lỗi môi trường máy chủ-máy khách (1)
  Nếu máy in đang được dùng làm máy in được chia sẻ, và hệ điều hành của máy 
  chủ đang được nâng cấp, sẽ có thể có một thông báo cho biết trình điều 
  khiển cần phải được cập nhật xuất hiện trên máy khách, khiến việc in bị thất bại.
  Trong trường hợp này, cần phải cài lại trình điều khiển máy in trên máy khách 
  để có thể in lại được.

- Lỗi môi trường máy chủ-máy khách (2)
  Trong môi trường Máy chủ - Máy khách, sau khi thêm hoặc nâng cấp
  một trình điều khiển in trên máy chủ, quá trình in có thể sẽ không
  thực hiện được và một thông báo xuất hiện yêu cầu nâng cấp
  trình điều khiển in bên phía máy khách.
  Bạn có thể tránh vấn đề này với thiết đặt dưới đây.

  <Thay đổi Thiết đặt chính sách nhóm trên Máy khách>
  1. Đăng nhập với vai trò Người quản trị trên Máy khách.
  2. Mở dấu nhắc lệnh và thực hiện lệnh "gpedit.msc" để mở [Local Group Policy Editor].
  3. Mở cây ở phía bên trái theo thứ tự như sau.
     [User Configuration]
     [Administrative Templates]
     [Control Panel]
     [Printers]
  4. Nhấp đúp vào [Point and Print Restrictions] trong ngăn bên phải.
  5. Nhấp vào nút chọn [Disabled].
  6. Nhấp [OK] để đóng cửa sổ.
  7. Đóng [Local Group Policy Editor].

4.2  LƯU Ý VÀ HẠN CHẾ theo trình điều khiển cụ thể cho Màu
------------------------------------------------------
* Về [Ưu tiên màu đã xác định trong ứng dụng khi Màu giấy ra
  là Đen trắng]
  Đối với kết quả in phù hợp với thiết đặt màu được
  xác định bởi giao diện người dùng của ứng dụng,
  đặt [In sử dụng màu đã xác định trong ứng dụng]
  và [Ưu tiên màu đã xác định trong ứng dụng khi
  Màu giấy ra là Đen trắng] thành [Bật].

  Diễn giải sau mô tả liên hệ giữa thiết đặt của
  trình điều khiển máy in ([Màu giấy ra], [In sử dụng
  màu đã xác định trong ứng dụng] và [Ưu tiên
  màu đã xác định trong ứng dụng khi Màu giấy ra
  là Đen trắng]) và kết quả in.

  * [In sử dụng màu đã xác định trong ứng dụng]: [Tắt]
    Màu giấy ra được xác định bởi ứng dụng sẽ bị bỏ qua
    và thiết đặt [Màu giấy ra] trên giao diện người dùng của
    trình điều khiển sẽ được sử dụng để in.

  * [In sử dụng màu đã xác định trong ứng dụng]: [Bật]
    - [Ưu tiên màu đã xác định trong ứng dụng khi
      Màu giấy ra là Đen trắng]: [Bật]
      Màu giấy ra được xác định bởi ứng dụng sẽ được sử dụng
      để in. Nếu không có Màu giấy ra được xác định bởi
      ứng dụng, thiết đặt [Màu giấy ra] trên giao diện người dùng
      của trình điều khiển sẽ được sử dụng để in.

    - [Ưu tiên màu đã xác định trong ứng dụng khi Màu giấy ra
      là Đen trắng]: [Tắt]
      Nếu thiết đặt [Màu giấy ra] trên giao diện người dùng
      của trình điều khiển là [Màu], Màu giấy ra được
      xác định bởi ứng dụng sẽ được sử dụng để in.
      Nếu thiết đặt [Màu giấy ra] trên giao diện người dùng
      của trình điều khiển là [Đen trắng], Màu giấy ra được
      xác định bởi ứng dụng sẽ bị bỏ qua và kết quả in
      sẽ là đen trắng. Nếu không có Màu giấy ra được
      xác định bởi ứng dụng, thiết đặt [Màu giấy ra] trên
      giao diện người dùng của trình điều khiển sẽ được
      sử dụng để in.

4.3  LƯU Ý VÀ HẠN CHẾ theo ứng dụng cụ thể
------------------------------------------------------------------
- Tuỳ thuộc vào ứng dụng được khách hàng sử dụng, các trang trống dùng để điều
chỉnh trang sẽ được chèn tự động, tuỳ thuộc vào các điều kiện như số bản sao
được chỉ định khi cho ra bản in 2 mặt.
Trong trường hợp ấy, các trang trống được chèn sẽ được thêm vào bởi ứng dụng.
Hiệu năng sẽ được cải thiện bằng cách thay đổi thiết đặt dưới đây.
- Đặt [Bỏ qua trang trống] tại thẻ [Nâng cao] thành [Bật].

4.4  LƯU Ý VÀ HẠN CHẾ theo ứng dụng cụ thể cho Màu
------------------------------------------------------------------
* Thiết đặt màu giấy ra từ ứng dụng
  Để in màu từ ứng dụng của Windows Store, mở mục
  [Thiết bị và máy in] từ Bàn làm việc của Windows, nhấp
  chuột phải vào máy in để chọn [Tùy chọn in] sau đó
  xác nhận rằng [Màu giấy ra] trong tab [Cơ bản]
  của hộp thoại [Tùy chọn in] được đặt thành [Màu].
  Nếu thiết đặt [Màu giấy ra] trong tab [Cơ bản]
  của hộp thoại [Tùy chọn in] vẫn là [Trắng đen], màu in ra
  sẽ vẫn là trắng đen cho dù bạn chỉ định Chế độ màu là
  [Màu] trên màn hình thiết đặt in được hiển thị sau khi
  bạn chọn máy in từ nút thiết bị.

---------------------------------------------------
5. Cập nhật phần mềm
---------------------------------------------------
    Phần mềm mới nhất có sẵn trên trang web của chúng tôi.

        https://fujifilm.com/fbglobal

    Phí liên lạc sẽ do khách hàng thanh toán.

--------------------------------------------------------------------------------
Microsoft, Windows và Windows Server là các thương hiệu
đã được đăng ký hoặc thương hiệu của Microsoft Corporation
tại Hoa Kỳ và/hoặc các quốc gia khác.

Các tên sản phẩm và tên công ty khác là thương hiệu hoặc
thương hiệu đã đăng ký của từng công ty tương ứng.

(C) FUJIFILM Business Innovation Corp. 2021-2025
