================================================================================
Kesepakatan Lisensi
================================================================================

Kesepakatan lisensi untuk perangkat lunak ini (selanjutnya disebut sebagai
PERANGKAT LUNAK) dapat dijelaskan sebagai berikut.

1 Hak kekayaan intelektual dalam PERANGKAT LUNAK tetap dimiliki oleh
   FUJIFILM Business Innovation Corp. (Selanjutnya disebut sebagai
   FUJIFILM Business Innovation) demikian juga sebagai pemegang hak cipta aslinya.

2 PERANGKAT LUNAK hanya boleh digunakan dengan produk yang kompatibel dengan
   FUJIFILM Business Innovation (selanjutnya disebut sebagai PRODUK KOMPATIBEL)
   di negara tempat PRODUK KOMPATIBEL tersebut dibeli.

3 Anda diminta mematuhi catatan dan pembatasan ini (selanjutnya disebut sebagai
   CATATAN DAN PEMBATASAN) yang dinyatakan oleh FUJIFILM Business Innovation 
   selama Anda menggunakan PERANGKAT LUNAK.

4 Anda tidak diizinkan untuk mengubah, memodifikasi, merekayasa balik,
   mendekompilasi atau membongkar seluruh atau sebagian PERANGKAT LUNAK
   untuk tujuan menganalisis PERANGKAT LUNAK.

5 Anda tidak diizinkan mendistribusikan PERANGKAT LUNAK kepada jaringan
   komunikasi, atau mentransfer, menjual, menyewakan atau melisensikan
   PERANGKAT LUNAK kepada pihak ketiga dengan menduplikasi PERANGKAT LUNAK
   pada media apa pun seperti floppy disk atau pita magnetik.

6 FUJIFILM Business Innovation, Mitra Saluran FUJIFILM Business Innovation,
   Dealer Resmi dan pemegang asli hak cipta
   PERANGKAT LUNAK tidak bertanggung jawab atas kehilangan atau kerusakan
   yang timbul akibat pencocokan perangkat keras atau program yang tidak
   ditentukan dalam CATATAN DAN PEMBATASAN PERANGKAT LUNAK,
   atau modifikasi pada PERANGKAT LUNAK.

7 FUJIFILM Business Innovation, Mitra Saluran FUJIFILM Business Innovation,
   Dealer Resmi dan pemegang asli hak cipta 
   PERANGKAT LUNAK tidak bertanggung jawab atas garansi atau tanggung jawab apa 
   pun sehubungan dengan PERANGKAT LUNAK.

================================================================================
PCL 6 Print Driver Ver.7.1.10
================================================================================

Dokumen ini memberikan informasi tentang  pada
item-item berikut:

1. Produk Perangkat Keras Target
2. Persyaratan
3. Komentar Umum
4. CATATAN DAN PEMBATASAN
  4.1  CATATAN DAN BATASAN Spesifik Driver
  4.2  CATATAN DAN BATASAN Spesifik Driver untuk Warna
  4.3  CATATAN DAN BATASAN Spesifik Aplikasi
  4.4  CATATAN DAN BATASAN Spesifik Aplikasi untuk Warna
5. Perbarui Perangkat Lunak

---------------------------------------------------
1. Produk Perangkat Keras Target
---------------------------------------------------
FUJIFILM Apeos 3560 / 3060 / 2560
         Apeos 3561 / 3061 / 2561
         Apeos 5330 / 4830
         Apeos 5570 / 4570
         Apeos 6340
         Apeos 7580 / 6580
         Apeos C3060 / C2560 / C2060
         Apeos C3061 / C2561 / C2061
         Apeos C3567 / C3067 / C2567
         Apeos C4030 / C3530
         Apeos C5240
         Apeos C7070 / C6570 / C5570 / C4570 / C3570 / C3070 / C2570
         Apeos C7071 / C6571 / C5571 / C4571 / C3571 / C3071
         Apeos C8180 / C7580 / C6580
         ApeosPrint 4560 S / 3960 S / 3360 S
         ApeosPrint 5330
         ApeosPrint 6340
         ApeosPrint C4030
         ApeosPrint C5240
         ApeosPrint C5570
         ApeosPro C810 / C750 / C650

---------------------------------------------------
2. Persyaratan
---------------------------------------------------
Harap dicatat bahwa driver ini beroperasi pada komputer yang menjalankan
sistem operasi berikut ini.

  Microsoft(R) Windows(R) 10 x64 Editions
  Microsoft(R) Windows Server(R) 2016
  Microsoft(R) Windows Server(R) 2019
  Microsoft(R) Windows(R) 11
  Microsoft(R) Windows Server(R) 2022
  Microsoft(R) Windows Server(R) 2025

  Kunjungi situs web kami untuk memeriksa perangkat lunak
  terbaru dan sistem operasi yang didukung.

 
---------------------------------------------------
3. Komentar Umum
---------------------------------------------------
* Tutup semua aplikasi yang dijalankan sebelum menginstal driver cetak.

* Selalu nyalakan ulang komputer setelah menginstal versi driver cetak
  yang diperbarui.

* Jika Anda telah menghapus versi driver cetak yang lama, selalu nyalakan
  ulang komputer sebelum menginstal versi yang baru.

* Beberapa aplikasi menyediakan opsi pencetakan terkait dengan jumlah
  salinan dan salinan kolase. Selalu pilih opsi pencetakan dalam aplikasi
  kecuali instruksi menentukan lain. Gunakan dialog driver cetak untuk
  memilih opsi lanjutan seperti Cetak 2 Sisi, Set Contoh, atau opsi yang
  tidak tersedia dalam aplikasi.

* Selalu tutup dialog driver cetak dan/atau kotak dialog Cetak aplikasi
  sebelum Anda melakukan perubahan pada pengaturan standar
  driver cetak melalui Panel Kontrol.

* Jika output Offset Pekerjaan Anda tidak bekerja dengan baik pada salinan
  kolase, cobalah untuk membatalkan pilihan opsi [Kolase] dalam aplikasi
  dan menandai kotak centang [Kolase] dalam driver cetak.

* Jika Buku Telepon Faks tidak diinisialisasi atau dibuat oleh pengguna saat ini,
  dia mungkin tidak diberikan wewenang untuk mengaksesnya. Untuk akses
  yang tidak patut oleh pengguna, driver akan menampilkan pesan kesalahan
  yang menunjukkan bahwa default Buku Telepon Faks tidak dapat ditemukan
  atau Buku Telepon Faks yang ditentukan tidak dapat dikenali.
  Di sisi lain, jika pengguna ingin Buku Telepon Faksnya diakses oleh pengguna
  lain, ia harus menentukan grup dan pengguna yang aksesnya dia izinkan, dan
  harus memberi mereka setidaknya izin 'Ubah' ke file data
  Buku Telepon Faks.

* Pekerjaan faks harus dikirim secara terpisah ke setiap penerima yang
  ditentukan dengan kode-F, Kata Sandi atau atribut pengiriman aman.
  Jika tidak, printer selalu mengabaikan kode-F, Kata Sandi dan pengiriman
  aman atribut saat mengirim pekerjaan faks ke beberapa penerima. Pekerjaan
  yang ditransmisikan selalu dicetak langsung di semua tujuan yang ditentukan.

* Untuk pemasangan melalui jaringan, jika Anda mengklik kanan
  pada folder [Printer], buka [Jalankan sebagai administrator] dari menu dan pilih
  [Tambah printer ...], ikon printer mungkin tidak dihasilkan.

* Penggantian nama Ikon Printer harus mematuhi konvensi penamaan file OS.
  Penggunaan Simbol atau karakter khusus dapat menyebabkan kesalahan
  penggantian nama atau perilaku driver cetak yang tidak terduga.

* Sebelum menginstal driver cetak di lingkungan cluster Windows, Anda perlu
  menginstalnya pada setiap node di cluster.

---------------------------------------------------
4. CATATAN DAN PEMBATASAN
---------------------------------------------------
4.1  CATATAN DAN BATASAN Spesifik Driver
-----------------------------------------------
*Tentang penggunaan printer bersama
  Kerusakan cetakan yang terjadi di dalam lingkungan printer bersama dapat
  diperbaiki dengan mengubah nilai [Lakukan pekerjaan cetak pada komputer klien].
  - Anotasi/Watermark tidak tercetak dengan baik, bahkan saat pengaturan berikut
    dipilih.
  - Pengaturan autentikasi tidak terefleksikan dengan baik, atau pesan
    autentikasi tidak muncul.

* Resolusi default driver ini adalah% DefaultResolution%. (Ditunjukkan Otomatis.)
  Saat mengeluarkan melalui driver, resolusi yang berbeda dari salah satu driver ini,
  kesalahan seperti berikut dapat diamati tergantung pada spesifikasi atau batasan
  aplikasi.
  - Tata letak dokumen dicetak diubah.
  - Hasil cetak dari garis atau pola diubah.
  - Garis yang tidak perlu dicetak pada output.
  - Garis yang diperlukan tidak dicetak pada output.

  Dalam kasus seperti itu, status dapat ditingkatkan dengan mengubah
  pengaturan [Resolusi] pada tab [Tingkat Lanjut].

* Bahkan dengan [Lompati Halaman Kosong] dipilih, halaman kosong mungkin
  masih dicetak dalam situasi berikut.
  - Halaman ini hanya berisi umpan baris.
  - Halaman ini hanya berisi spasi.
  - Halaman ini hanya berisi feed dan spasi baris.
  - Instruksi gambar latar belakang putih dikirim dari aplikasi.

* Catatan dan batasan tentang lingkungan server-klien
- Masalah Lingkungan Server-Klien (1)
  Jika printer sedang digunakan sebagai printer bersama dan operasi server
  sistem sedang ditingkatkan, pesan yang menunjukkan bahwa driver harus
  diperbarui dapat muncul pada klien, menyebabkan pencetakan gagal.
  Dalam hal ini, driver cetak harus diinstal ulang pada klien supaya dapat
  mencetak lagi.

- Masalah Lingkungan Server-Klien (2)
  Di lingkungan Server-Client, setelah driver cetak ditambahkan atau
  ditingkatkan di sisi Server, pencetakan mungkin tidak dilakukan dengan
  pesan yang ditampilkan membutuhkan peningkatan driver cetak di sisi Klien.
  Masalah ini dapat dihindari dengan pengaturan di bawah ini.

  < Ubah Pengaturan Kebijakan Grup pada PC Klien >
  1. Masuk sebagai Administrator pada PC Klien.
  2. Buka perintah prompt dan lakukan "gpedit.msc". Untuk membuka [Editor
     Kebijakan Grup Lokal].
  3. Buka pohon di sebelah kiri dengan urutan berikut ini.
     [Konfigurasi Pengguna]
     [Templat Administratif]
     [Panel Kontrol]
     [Printer]
  4. Klik dua kali [Tunjuk dan Cetak Batasan] di panel kanan.
  5. Klik tombol radio [Nonaktif].
  6. Klik [OK] untuk menutup jendela.
  7. Tutup [Editor Kebijakan Grup Lokal].

4.2  CATATAN DAN BATASAN Spesifik Driver untuk Warna
------------------------------------------------------
* Tentang [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]
  Untuk hasil cetak yang konsisten dengan pengaturan warna yang ditentukan oleh
  UI aplikasi, atur [Cetak Menggunakan Warna Tertentu Aplikasi] dan [Prioritaskan
  Warna Tertentu Aplikasi saat Warna Output Hitam Putih] ke [On].

  Berikut ini menjelaskan hubungan antara pengaturan driver printer ([Warna Output],
  [Cetak Menggunakan Warna Tertentu Aplikasi], dan [Prioritaskan Warna Tertentu
  Aplikasi saat Warna Output Hitam Putih]), dan output cetak.

  * [Cetak Menggunakan Warna Tertentu Aplikasi]: [Off]
    Warna Output yang ditentukan oleh aplikasi akan diabaikan, dan pengaturan
    [Warna Output] UI driver akan digunakan untuk mencetak.

  * [Cetak Menggunakan Warna Tertentu Aplikasi]: [On]
    - [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]: [On]
      Warna Output yang ditentukan oleh aplikasi akan digunakan untuk mencetak.
      Jika tidak ada Warna Output ditentukan oleh aplikasi, pengaturan [Warna Output]
      driver UI akan digunakan untuk mencetak.

    - [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]: [Off]
      Jika pengaturan [Warna Output] driver UI adalah [Warna], Warna Output yang
      ditentukan oleh aplikasi akan digunakan untuk mencetak.
      Jika pengaturan [Warna Output] driver UI adalah [Hitam Putih], Warna Output
      ditentukan oleh aplikasi akan diabaikan, dan hasil cetak akan menjadi hitam putih.
      Jika tidak ada Warna Output ditentukan oleh aplikasi, pengaturan [Warna Output]
      driver UI akan digunakan untuk mencetak.

4.3  CATATAN DAN BATASAN Spesifik Aplikasi
------------------------------------------------------------------
- Tergantung aplikasi yang digunakan oleh konsumen, halaman kosong untuk
penyesuaian halaman akan disisipkan secara otomatis berdasarkan kondisi
seperti jumlah salinan yang dipilih saat meng-output cetak 2 sisi.
Di sini, sisipan kosong akan disertakan dalam aplikasi.
Performa diperbaiki dengan mengubah pengaturan di bawah.
- Atur [Lompati Halaman Kosong] pada tab [Lanjutan] ke [On].

4.4  CATATAN DAN BATASAN Spesifik Aplikasi untuk Warna
------------------------------------------------------------------
* Pengaturan Warna Output dari Aplikasi
  Untuk mencetak warna dari Aplikasi Windows Store, buka [Peranti dan Pencetak]
  dari Windows Desktop, klik kanan pada printer Anda untuk memilih [Preferensi
  Pencetakan] dan kemudian konfirmasikan bahwa [Warna Output] pada tab
  [Dasar] pada dialog [Preferensi Pencetakan] diatur ke [Warna].
  Jika pengaturan [Warna Output] pada tab [Dasar] pada dialog [Preferensi
  Pencetakan] tetap [Hitam Putih], output akan berwarna hitam dan putih bahkan jika
  Anda menentukan Mode Berwarna ke [Warna] pada layar pengaturan pencetakan
  ditampilkan setelah Anda memilih printer dari pesona perangkat.
---------------------------------------------------
5. Perbarui Perangkat Lunak
---------------------------------------------------
    Perangkat lunak terkini tersedia di situs web kami.

        https://fujifilm.com/fbglobal

    Biaya komunikasi menjadi tanggungan pelanggan.

--------------------------------------------------------------------------------
Microsoft, Windows, dan Windows Server adalah merek dagang terdaftar
atau merek dagang milik Microsoft Corporation di Amerika Serikat
dan/atau negara lainnya.

Nama perusahaan dan nama produk lain adalah merek dagang atau merek
dagang teregistrasi milik perusahaan-perusahaan terkait.

(C) FUJIFILM Business Innovation Corp. 2021-2025
